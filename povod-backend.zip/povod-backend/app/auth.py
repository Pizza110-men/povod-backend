"""Аутентификация через Telegram Mini App.

Как это работает:
1. Telegram открывает мини-апп и передаёт ей строку initData —
   подписанные данные о пользователе (id, имя и т.д.).
2. Мини-апп отправляет initData на наш backend.
3. Мы проверяем подпись HMAC-SHA256 с помощью токена бота —
   подделать её без токена невозможно.
4. Если подпись верна — находим или создаём пользователя и выдаём наш JWT.

Пароли не нужны вовсе: Telegram уже подтвердил личность.
"""
import hashlib
import hmac
import json
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import parse_qsl

import jwt  # PyJWT
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from .config import settings
from .database import get_db
from .models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/telegram")

INIT_DATA_MAX_AGE = 60 * 60 * 24  # initData старше суток не принимаем


def verify_telegram_init_data(init_data: str) -> dict:
    """Проверяет подпись initData. Возвращает данные пользователя Telegram."""
    if not settings.BOT_TOKEN:
        raise HTTPException(500, "На сервере не задан POVOD_BOT_TOKEN")

    parsed = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = parsed.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Некорректные данные Telegram (нет подписи)")

    # Алгоритм проверки из документации Telegram
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(parsed.items()))
    secret_key = hmac.new(b"WebAppData", settings.BOT_TOKEN.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Подпись Telegram не совпадает")

    auth_date = int(parsed.get("auth_date", "0"))
    if time.time() - auth_date > INIT_DATA_MAX_AGE:
        raise HTTPException(401, "Сессия устарела, переоткройте мини-апп")

    try:
        return json.loads(parsed["user"])
    except (KeyError, json.JSONDecodeError):
        raise HTTPException(401, "В данных Telegram нет пользователя")


def create_access_token(user_id: int) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {"sub": str(user_id), "exp": expire}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def get_current_user(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> User:
    cred_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED, detail="Недействительный токен"
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        raise cred_error

    user = db.get(User, user_id)
    if user is None or user.is_banned:
        raise cred_error
    return user
