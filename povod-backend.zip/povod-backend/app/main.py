"""Повод — backend. Запуск: uvicorn app.main:app --reload"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import chat, povods, users

# Для MVP создаём таблицы при старте; в проде — миграции Alembic.
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Повод API",
    description="Знакомства через конкретные приглашения: место, время, повод.",
    version="0.1.0",
)

# В проде сузить до домена фронтенда
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(povods.router)
app.include_router(chat.router)


@app.get("/health")
def health():
    return {"status": "ok"}
