"""Чат внутри мэтча: REST-история + WebSocket для реального времени.

Чат доступен только участникам мэтча и только пока не истёк expires_at (48 ч).
Для MVP менеджер соединений держится в памяти процесса; при нескольких
инстансах backend его заменяют на Redis pub/sub.
"""
import jwt
from fastapi import (
    APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect,
)
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import get_current_user
from ..config import settings
from ..database import SessionLocal, get_db
from ..models import Match, Message, User, utcnow
from ..schemas import MessageCreate, MessagePublic

router = APIRouter(prefix="/matches", tags=["chat"])


def _get_match_for(user_id: int, match_id: int, db: Session) -> Match:
    match = db.get(Match, match_id)
    if not match or user_id not in (match.author_id, match.responder_id):
        raise HTTPException(404, "Чат не найден")
    if match.expires_at <= utcnow():
        raise HTTPException(410, "Чат истёк: 48 часов на согласование прошли")
    return match


@router.get("/{match_id}/messages", response_model=list[MessagePublic])
def history(
    match_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _get_match_for(user.id, match_id, db)
    q = (
        select(Message)
        .where(Message.match_id == match_id)
        .order_by(Message.created_at)
        .limit(500)
    )
    return db.scalars(q).all()


@router.post("/{match_id}/messages", response_model=MessagePublic, status_code=201)
def send(
    match_id: int,
    data: MessageCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _get_match_for(user.id, match_id, db)
    msg = Message(match_id=match_id, sender_id=user.id, text=data.text)
    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg


# ——— WebSocket ———————————————————————————————————————————
class ConnectionManager:
    """match_id -> список активных сокетов (MVP, один процесс)."""

    def __init__(self):
        self.rooms: dict[int, list[WebSocket]] = {}

    async def connect(self, match_id: int, ws: WebSocket):
        await ws.accept()
        self.rooms.setdefault(match_id, []).append(ws)

    def disconnect(self, match_id: int, ws: WebSocket):
        room = self.rooms.get(match_id, [])
        if ws in room:
            room.remove(ws)

    async def broadcast(self, match_id: int, payload: dict):
        for ws in self.rooms.get(match_id, []):
            await ws.send_json(payload)


manager = ConnectionManager()


@router.websocket("/{match_id}/ws")
async def chat_ws(ws: WebSocket, match_id: int, token: str):
    """Подключение: wss://.../matches/{id}/ws?token=<JWT>."""
    # Аутентификация вручную: Depends(oauth2) не работает в websocket с query-токеном
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        await ws.close(code=4401)
        return

    db = SessionLocal()
    try:
        match = db.get(Match, match_id)
        if (
            not match
            or user_id not in (match.author_id, match.responder_id)
            or match.expires_at <= utcnow()
        ):
            await ws.close(code=4404)
            return

        await manager.connect(match_id, ws)
        try:
            while True:
                text = (await ws.receive_text()).strip()
                if not text or len(text) > 2000:
                    continue
                if match.expires_at <= utcnow():
                    await ws.send_json({"type": "expired"})
                    break
                msg = Message(match_id=match_id, sender_id=user_id, text=text)
                db.add(msg)
                db.commit()
                await manager.broadcast(match_id, {
                    "type": "message",
                    "id": msg.id,
                    "sender_id": user_id,
                    "text": text,
                    "created_at": msg.created_at.isoformat(),
                })
        except WebSocketDisconnect:
            pass
        finally:
            manager.disconnect(match_id, ws)
    finally:
        db.close()
