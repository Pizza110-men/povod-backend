"""Поводы: создание, лента, отклики, принятие отклика (= мэтч)."""
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from ..auth import get_current_user
from ..config import settings
from ..database import get_db
from ..models import Match, Povod, Response, ResponseStatus, User, utcnow
from ..schemas import MatchPublic, PovodCreate, PovodPublic, ResponsePublic

router = APIRouter(prefix="/povods", tags=["povods"])


@router.post("", response_model=PovodPublic, status_code=201)
def create_povod(
    data: PovodCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if user.age is None or not user.city:
        raise HTTPException(400, "Сначала заполните профиль: возраст и город")
    if data.starts_at <= utcnow():
        raise HTTPException(400, "Время встречи должно быть в будущем")
    povod = Povod(author_id=user.id, **data.model_dump())
    db.add(povod)
    db.commit()
    db.refresh(povod)
    return povod


@router.get("/feed", response_model=list[PovodPublic])
def feed(
    city: str | None = None,
    category: str | None = None,
    limit: int = 20,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Лента: активные будущие поводы в городе пользователя, кроме своих
    и тех, на которые уже откликнулся."""
    responded = select(Response.povod_id).where(Response.user_id == user.id)
    q = (
        select(Povod)
        .options(joinedload(Povod.author))
        .where(
            Povod.is_active.is_(True),
            Povod.starts_at > utcnow(),
            Povod.author_id != user.id,
            Povod.city == (city or user.city),
            Povod.id.not_in(responded),
        )
        .order_by(Povod.starts_at)
        .limit(min(limit, 50))
    )
    if category:
        q = q.where(Povod.category == category)
    return db.scalars(q).all()


@router.post("/{povod_id}/respond", status_code=201)
def respond(
    povod_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    povod = db.get(Povod, povod_id)
    if not povod or not povod.is_active:
        raise HTTPException(404, "Повод не найден или уже неактивен")
    if povod.author_id == user.id:
        raise HTTPException(400, "Нельзя откликнуться на свой повод")
    dup = db.scalar(
        select(Response).where(
            Response.povod_id == povod_id, Response.user_id == user.id
        )
    )
    if dup:
        raise HTTPException(409, "Вы уже откликнулись на этот повод")

    db.add(Response(povod_id=povod_id, user_id=user.id))
    db.commit()
    return {"status": "ok", "detail": "Отклик отправлен"}


@router.get("/{povod_id}/responses", response_model=list[ResponsePublic])
def list_responses(
    povod_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Автор повода видит, кто откликнулся."""
    povod = db.get(Povod, povod_id)
    if not povod:
        raise HTTPException(404, "Повод не найден")
    if povod.author_id != user.id:
        raise HTTPException(403, "Отклики видит только автор повода")
    q = (
        select(Response)
        .options(joinedload(Response.user))
        .where(Response.povod_id == povod_id,
               Response.status == ResponseStatus.pending)
    )
    return db.scalars(q).all()


@router.post("/responses/{response_id}/accept", response_model=MatchPublic)
def accept_response(
    response_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Автор принимает отклик → мэтч + чат на 48 часов, повод закрывается."""
    resp = db.get(Response, response_id)
    if not resp:
        raise HTTPException(404, "Отклик не найден")
    povod = db.get(Povod, resp.povod_id)
    if povod.author_id != user.id:
        raise HTTPException(403, "Принять отклик может только автор повода")
    if resp.status != ResponseStatus.pending:
        raise HTTPException(409, "Отклик уже обработан")

    resp.status = ResponseStatus.accepted
    povod.is_active = False  # повод закрыт: пара найдена
    match = Match(
        povod_id=povod.id,
        author_id=user.id,
        responder_id=resp.user_id,
        expires_at=utcnow() + timedelta(hours=settings.CHAT_TTL_HOURS),
    )
    db.add(match)
    # остальные отклики отклоняем
    others = db.scalars(
        select(Response).where(
            Response.povod_id == povod.id,
            Response.status == ResponseStatus.pending,
            Response.id != resp.id,
        )
    )
    for o in others:
        o.status = ResponseStatus.declined
    db.commit()
    db.refresh(match)
    return match


@router.get("/matches", response_model=list[MatchPublic])
def my_matches(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    q = (
        select(Match)
        .options(joinedload(Match.povod).joinedload(Povod.author))
        .where(
            ((Match.author_id == user.id) | (Match.responder_id == user.id)),
            Match.expires_at > utcnow(),
        )
        .order_by(Match.created_at.desc())
    )
    return db.scalars(q).all()
