"""Вход через Telegram, профиль, жалобы."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import create_access_token, get_current_user, verify_telegram_init_data
from ..database import get_db
from ..models import Report, User
from ..schemas import (
    AuthResult, ProfileUpdate, ReportCreate, TelegramAuth, UserPublic,
)

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/telegram", response_model=AuthResult)
def telegram_login(data: TelegramAuth, db: Session = Depends(get_db)):
    """Мини-апп присылает initData → получает JWT.
    Если пользователь новый — создаём его с именем из Telegram."""
    tg_user = verify_telegram_init_data(data.init_data)

    user = db.scalar(select(User).where(User.telegram_id == tg_user["id"]))
    if user is None:
        user = User(
            telegram_id=tg_user["id"],
            name=(tg_user.get("first_name") or "Без имени")[:80],
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    if user.is_banned:
        raise HTTPException(403, "Аккаунт заблокирован")

    needs_onboarding = user.age is None or not user.city
    return AuthResult(
        access_token=create_access_token(user.id),
        needs_onboarding=needs_onboarding,
        user=user,
    )


@router.get("/me", response_model=UserPublic)
def me(user: User = Depends(get_current_user)):
    return user


@router.patch("/me", response_model=UserPublic)
def update_profile(
    data: ProfileUpdate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Онбординг и редактирование: возраст (18+), город, о себе."""
    if data.age is not None:
        user.age = data.age
    if data.city is not None:
        user.city = data.city.strip()
    if data.bio is not None:
        user.bio = data.bio.strip()
    db.commit()
    db.refresh(user)
    return user


@router.post("/report", status_code=201)
def report(
    data: ReportCreate,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Жалоба на пользователя — обязательный механизм безопасности."""
    if data.target_user_id == user.id:
        raise HTTPException(400, "Нельзя пожаловаться на себя")
    db.add(Report(
        reporter_id=user.id,
        target_user_id=data.target_user_id,
        povod_id=data.povod_id,
        reason=data.reason,
    ))
    db.commit()
    return {"status": "ok", "detail": "Жалоба отправлена на модерацию"}
