"""Pydantic-схемы (валидация входа/выхода API)."""
from datetime import datetime

from pydantic import BaseModel, Field, ConfigDict


# ——— Пользователи / auth ———
class TelegramAuth(BaseModel):
    """Строка initData, которую Telegram передаёт мини-аппу."""
    init_data: str = Field(min_length=10)


class UserPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    age: int | None
    city: str
    bio: str


class ProfileUpdate(BaseModel):
    age: int | None = Field(default=None, ge=18, le=100)  # только 18+
    city: str | None = Field(default=None, min_length=1, max_length=80)
    bio: str | None = Field(default=None, max_length=300)


class AuthResult(BaseModel):
    access_token: str
    token_type: str = "bearer"
    needs_onboarding: bool
    user: UserPublic


# ——— Поводы ———
class PovodCreate(BaseModel):
    title: str = Field(min_length=3, max_length=120)
    category: str = Field(max_length=40)
    place: str = Field(min_length=2, max_length=160)
    city: str = Field(min_length=1, max_length=80)
    starts_at: datetime
    note: str = Field(default="", max_length=300)


class PovodPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    category: str
    place: str
    city: str
    starts_at: datetime
    note: str
    author: UserPublic


# ——— Отклики и мэтчи ———
class ResponsePublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    status: str
    user: UserPublic


class MatchPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    povod: PovodPublic
    expires_at: datetime


# ——— Чат ———
class MessageCreate(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class MessagePublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    sender_id: int
    text: str
    created_at: datetime


# ——— Жалобы ———
class ReportCreate(BaseModel):
    target_user_id: int
    povod_id: int | None = None
    reason: str = Field(min_length=3, max_length=500)
