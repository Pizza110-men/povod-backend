"""Конфигурация приложения. Все значения переопределяются переменными окружения."""
import os

class Settings:
    # В проде обязательно задать через env: openssl rand -hex 32
    SECRET_KEY: str = os.getenv("POVOD_SECRET_KEY", "dev-secret-change-me")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # неделя

    # SQLite для разработки; в проде: postgresql+psycopg://user:pass@host/povod
    DATABASE_URL: str = os.getenv("POVOD_DATABASE_URL", "sqlite:///./povod.db")

    # Сколько живёт чат после мэтча
    CHAT_TTL_HOURS: int = int(os.getenv("POVOD_CHAT_TTL_HOURS", "48"))

    # Токен вашего Telegram-бота от @BotFather (обязателен для входа через мини-апп)
    BOT_TOKEN: str = os.getenv("POVOD_BOT_TOKEN", "")

settings = Settings()
