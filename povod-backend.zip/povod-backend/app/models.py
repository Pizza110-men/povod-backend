"""Модели данных.

Схема:
  User ──< Povod ──< Response >── User
                └──< Match (создаётся при принятом отклике)
                          └──< Message
  Report — жалобы (обязательное требование App Store / Google Play для дейтинга).
"""
import enum
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean, DateTime, Enum, ForeignKey, Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ResponseStatus(str, enum.Enum):
    pending = "pending"      # отклик отправлен, автор повода ещё не решил
    accepted = "accepted"    # автор принял → создан Match
    declined = "declined"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    # Вход только через Telegram: пароли не храним вообще
    telegram_id: Mapped[int] = mapped_column(Integer, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(80))
    age: Mapped[int | None] = mapped_column(Integer, nullable=True)  # заполняется в онбординге
    city: Mapped[str] = mapped_column(String(80), index=True, default="")
    bio: Mapped[str] = mapped_column(String(300), default="")
    is_banned: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    povods: Mapped[list["Povod"]] = relationship(back_populates="author")


class Povod(Base):
    """Повод = конкретное приглашение: что, где, когда."""
    __tablename__ = "povods"

    id: Mapped[int] = mapped_column(primary_key=True)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    title: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(40), index=True)
    place: Mapped[str] = mapped_column(String(160))
    city: Mapped[str] = mapped_column(String(80), index=True)
    starts_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    note: Mapped[str] = mapped_column(String(300), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    author: Mapped[User] = relationship(back_populates="povods")
    responses: Mapped[list["Response"]] = relationship(back_populates="povod")


class Response(Base):
    """Отклик пользователя на повод. Один пользователь — один отклик на повод."""
    __tablename__ = "responses"
    __table_args__ = (UniqueConstraint("povod_id", "user_id", name="uq_response"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    povod_id: Mapped[int] = mapped_column(ForeignKey("povods.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    status: Mapped[ResponseStatus] = mapped_column(
        Enum(ResponseStatus), default=ResponseStatus.pending
    )
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    povod: Mapped[Povod] = relationship(back_populates="responses")
    user: Mapped[User] = relationship()


class Match(Base):
    """Мэтч: автор повода принял отклик. Чат живёт до expires_at."""
    __tablename__ = "matches"

    id: Mapped[int] = mapped_column(primary_key=True)
    povod_id: Mapped[int] = mapped_column(ForeignKey("povods.id"))
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    responder_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    povod: Mapped[Povod] = relationship()
    messages: Mapped[list["Message"]] = relationship(back_populates="match")


class Message(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"), index=True)
    sender_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    match: Mapped[Match] = relationship(back_populates="messages")


class Report(Base):
    """Жалоба на пользователя или повод — требование сторов для дейтинг-приложений."""
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    reporter_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    target_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    povod_id: Mapped[int | None] = mapped_column(ForeignKey("povods.id"), nullable=True)
    reason: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
