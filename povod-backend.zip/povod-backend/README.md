# Повод — backend (MVP)

Знакомства через конкретные приглашения: **что, где, когда**. Свайпают не людей, а поводы встретиться. Принятый отклик открывает чат на 48 часов — ровно чтобы договориться о деталях.

## Запуск за 2 минуты

```bash
python3 -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Откройте http://127.0.0.1:8000/docs — интерактивная документация API (Swagger), можно тестировать все запросы прямо из браузера.

## Механика в 5 шагов

1. `POST /auth/register` — регистрация (только 18+), сразу возвращает JWT
2. `POST /povods` — публикация повода (название, место, город, время)
3. `GET /povods/feed` — лента чужих поводов в вашем городе
4. `POST /povods/{id}/respond` — отклик; автор видит его в `GET /povods/{id}/responses`
5. `POST /povods/responses/{id}/accept` — автор принимает отклик → **мэтч**, повод закрывается, открывается чат на 48 ч

Чат: `GET/POST /matches/{id}/messages` или WebSocket `ws://127.0.0.1:8000/matches/{id}/ws?token=<JWT>`.

## Быстрый тест (curl)

```bash
# Регистрируем Аню
TOKEN_A=$(curl -s -X POST localhost:8000/auth/register -H 'Content-Type: application/json' \
  -d '{"email":"anya@test.ru","password":"password123","name":"Аня","age":27,"city":"Москва"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")

# Аня создаёт повод
curl -s -X POST localhost:8000/povods -H "Authorization: Bearer $TOKEN_A" -H 'Content-Type: application/json' \
  -d '{"title":"Ночной Хичкок","category":"Кино","place":"Иллюзион","city":"Москва","starts_at":"2026-07-20T21:30:00Z"}'

# Регистрируем Мишу — он видит повод в ленте и откликается
TOKEN_B=$(curl -s -X POST localhost:8000/auth/register -H 'Content-Type: application/json' \
  -d '{"email":"misha@test.ru","password":"password123","name":"Миша","age":29,"city":"Москва"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")

curl -s localhost:8000/povods/feed -H "Authorization: Bearer $TOKEN_B"
curl -s -X POST localhost:8000/povods/1/respond -H "Authorization: Bearer $TOKEN_B"

# Аня принимает отклик → мэтч + чат на 48ч
curl -s localhost:8000/povods/1/responses -H "Authorization: Bearer $TOKEN_A"
curl -s -X POST localhost:8000/povods/responses/1/accept -H "Authorization: Bearer $TOKEN_A"
```

## Структура

```
app/
├── main.py          # точка входа FastAPI
├── config.py        # настройки (env-переменные)
├── database.py      # SQLAlchemy
├── models.py        # User, Povod, Response, Match, Message, Report
├── schemas.py       # Pydantic-валидация
├── auth.py          # JWT + bcrypt
└── routers/
    ├── users.py     # регистрация, вход, жалобы
    ├── povods.py    # лента, поводы, отклики, мэтчи
    └── chat.py      # история + WebSocket
```

## Что дальше (по мере роста)

- **Миграции**: Alembic вместо `create_all`
- **Прод-БД**: PostgreSQL (`POVOD_DATABASE_URL=postgresql+psycopg://...`)
- **Фото**: загрузка в S3-совместимое хранилище + модерация (обязательна для сторов)
- **Push-уведомления**: FCM/APNs при отклике и мэтче
- **Чат на нескольких инстансах**: Redis pub/sub вместо in-memory менеджера
- **Верификация профилей** и rate-limiting против ботов

⚠️ Перед продом: задайте `POVOD_SECRET_KEY` (`openssl rand -hex 32`), сузьте CORS до домена фронтенда, включите HTTPS.
